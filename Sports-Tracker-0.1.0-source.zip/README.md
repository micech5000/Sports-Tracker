# Sports Tracker

Компактное Windows-приложение для просмотра live, предстоящих и завершённых спортивных событий.

## Текущий этап

Сейчас приложение работает на демонстрационных данных. Реальный спортивный API и backend-прокси будут подключены следующим этапом.

## Структура

- `desktop/` — Electron + React + TypeScript приложение.
- `backend/` — заготовка backend-прокси.
- `docs/` — архитектурные заметки.

## Запуск

Требуется Node.js LTS.

```bash
npm install
npm run dev:desktop
```

## Проверки

```bash
npm run typecheck:desktop
npm run lint:desktop
npm run build:desktop
```

## Безопасность

API-ключи не должны находиться в React-коде, Electron renderer или GitHub. Они будут храниться только в переменных окружения backend-прокси.
