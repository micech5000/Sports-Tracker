import "dotenv/config";
import cors from "cors";
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";

const app = express();
const port = Number(process.env.PORT ?? 3000);
const allowedSports = new Set(["football", "basketball", "tennis"]);

app.use(helmet());
app.use(
  cors({
    origin: process.env.FRONTEND_ORIGIN || true,
  }),
);
app.use(express.json());
app.use(
  "/api",
  rateLimit({
    windowMs: 60_000,
    limit: 60,
    standardHeaders: "draft-8",
    legacyHeaders: false,
  }),
);

app.get("/health", (_request, response) => {
  response.json({ ok: true, service: "sports-tracker-backend" });
});

app.get("/api/events", (request, response) => {
  const sport = String(request.query.sport ?? "football");
  const date = String(request.query.date ?? "");

  if (!allowedSports.has(sport)) {
    response.status(400).json({
      error: "Unsupported sport",
      allowedSports: [...allowedSports],
    });
    return;
  }

  if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    response.status(400).json({
      error: "Date must use YYYY-MM-DD format",
    });
    return;
  }

  response.json({
    source: "mock",
    sport,
    date: date || null,
    events: [],
    message: "Real sports provider integration will be added next.",
  });
});

app.listen(port, () => {
  console.log(`Sports Tracker backend listening on port ${port}`);
});
