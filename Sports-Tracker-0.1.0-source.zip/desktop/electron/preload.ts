import { contextBridge } from "electron";

contextBridge.exposeInMainWorld("sportsTracker", {
  platform: process.platform,
});
