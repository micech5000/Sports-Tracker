/// <reference types="vite/client" />

interface Window {
  sportsTracker?: {
    platform: NodeJS.Platform;
  };
}
